function validation() {

var errors=new Array();

    var username = document.getElementById("name").value;
    var uemail = document.getElementById("email").value;
    var password = document.getElementById("pass").value;
    var date = document.getElementById("dob").value;
    var phone = document.getElementById("phone1").value;
    
    var un=/^[A-Za-z0-9_]{1,20}$/;
    var ue=/^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+\.[A-Za-z]{2,4}$/;
    var up=/^^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
    var dt=/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
    var pn=/^[0-9]{10}$/;
   

    if (!un.test(username)) {
        errors[errors.length]="\n username must be filled out";
     }
    if(!ue.test(uemail)){
      errors[errors.length]="\n enter valid email id";
      }
    if(!up.test(password)){
      errors[errors.length]="\n Password must be contain length of 8,capital latter,small latter,numbers and spacial character";
      }
    if(!dt.test(date)){
      errors[errors.length]="\n date must be in date format ex:- 29/07/1999";
      }
    if(!pn.test(phone)){
      errors[errors.length]="\n phone must be contain length of 10 numbers";
      } 
      if(errors.length!=0)
alert(errors);

}

function validati() {
var error=new Array();

    var username = document.getElementById("name1").value;
    var uemail = document.getElementById("email1").value;
    var password = document.getElementById("pass1").value;

    
    var un=/^[A-Za-z0-9_]{1,20}$/;
    var ue=/^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+\.[A-Za-z]{2,4}$/;
    var up=/^^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
   

    if (!un.test(username)) {
        error[error.length]="\n username must be filled out";
        }
    if(!ue.test(uemail)){
      error[error.length]="\n enter valid email id";
      }
    if(!up.test(password)){
      error[error.length]="\n Password must be contain length of 8,capital latter,small latter,numbers and spacial character";
      }
   if(error.length!=0)
alert(error);

}


function validatiyo() {
var error=new Array();

    var username = document.getElementById("name").value;
    var uemail = document.getElementById("email").value;


    
    var un=/^[A-Za-z0-9_]{1,20}$/;
    var ue=/^[A-Za-z0-9._-]+@[A-Za-z0-9._-]+\.[A-Za-z]{2,4}$/;
   
   

    if (!un.test(username)) {
        error[error.length]="\n username must be filled out";
        }
    if(!ue.test(uemail)){
      error[error.length]="\n enter valid email id";
      }
    
   if(error.length!=0)
alert(error);

}
