<div class="login-form"><!--login form-->
            <h2><b><center>Login to your account</center></b></h2>
            <form action="#" name="loginform" onsubmit="validati()">
              <input type="text" placeholder="Name" id="name1"  />
              <input type="text" placeholder="Email Address" id="email1" />
              <input type="password" placeholder="Password" id="pass1"/>
              <button type="submit" class="btn btn-default"><b>Login</b></button>
            </form>
          </div><!--/login form-->