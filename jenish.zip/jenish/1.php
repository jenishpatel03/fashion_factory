<?php
//abstract , multilevel inheritance, constructor-destructor, access specifiers
abstract class employee
{
abstract function purpose();
}

class teacher extends employee
{
function __construct($reg){
$this->reg = $reg;
}


function purpose(){
echo "teacher is used as a means of employee.<br>";
}

public function display(){

echo "empid number: ".$this->reg."<br>";
}

}

class assistance extends teacher
{

function __construct($reg,$type)
{
parent::__construct($reg);
$this->type = $type;

}

public function display(){

parent::display();
echo "Type of teacher   : ".$this->type."<br>";
}
}

class income  extends assistance
{
private $name;
function __construct($reg,$type,$attribute,$value)
{
parent::__construct($reg,$type,$attribute,$value);
$this->attribute=$attribute;
$this->value=$value;

}
public function setName($name){
$this->name=$name;
}

public function getName(){
return $this->name;
}
public function display(){

parent::display();
echo "salary of teacher : ".$this->attribute."<br>salary of assistance   : ".$this->value."<br>";
}
}

echo "employee management <br>";
echo "<br>";
echo " teacher 1 <br>";
$y = new income ("1"," maths "," 100000 "," 10500 ");
$y->setName(" tapan sir ");
echo "Name of teacher : ".$y->getName()."<br>";
$y->display();

echo "<br><br>";
echo "<br>";
echo " teacher 2 <br>";
$y = new income (" 2 "," sports "," 20000 "," 2000");
$y->setName(" bapu sir");
echo "Name of teacher : ".$y->getName()."<br>";
$y->display();

?>
